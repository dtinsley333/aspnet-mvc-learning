﻿namespace GoogleChartsExample.Models
{
    public class SalesChartModel
    {
        public string Title { get; set; }
        public string Subtitle { get; set; }
        public GoogleVisualizationDataTable DataTable { get; set; }
    }
}