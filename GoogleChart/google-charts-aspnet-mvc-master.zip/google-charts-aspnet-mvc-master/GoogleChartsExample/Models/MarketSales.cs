﻿namespace GoogleChartsExample.Models
{
    public class MarketSales
    {
        public string Market { get; set; }
        public int Year { get; set; }
        public decimal TotalSales { get; set; }
    }
}