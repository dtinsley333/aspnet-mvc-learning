# MVC-w-Entity-Framework-Code-First-Sample
A simple project demo that is created using ASP.net MVC. Used an Entity Framework Code First Approach.
#Created by John Daniel Martin
#2016-03-22
